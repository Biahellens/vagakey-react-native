package com.github.vagakey.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VagakeyApplicationTests {

	@Test
	void contextLoads() {
	}

}
