package com.github.vagakey.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VagakeyApplication {

	public static void main(String[] args) {
		SpringApplication.run(VagakeyApplication.class, args);
	}

}
