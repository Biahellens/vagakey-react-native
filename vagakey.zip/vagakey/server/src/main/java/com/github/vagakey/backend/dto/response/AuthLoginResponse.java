package com.github.vagakey.backend.dto.response;

import lombok.Data;

@Data
public class AuthLoginResponse {

    private String token;

}
